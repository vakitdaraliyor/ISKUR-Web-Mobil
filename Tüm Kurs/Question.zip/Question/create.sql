
SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL';

-- Eğer bir şema zaten varsa bunu siliyor
DROP SCHEMA IF EXISTS inka;

-- Firma diye bir şema oluşturmak için
CREATE SCHEMA inka;

-- Tekrar tekra inka.personel inka.gorev 
USE inka;

create table gorev
	(gorev_id		int(10) NOT NULL AUTO_INCREMENT,
	 gorev_adi		varchar(30),
	 primary key (gorev_id)
	) ENGINE=InnoDB DEFAULT CHARSET=latin5 COLLATE=latin5_turkish_ci;
 

  create table departman
	(dept_id         int(10) NOT NULL AUTO_INCREMENT,
	 dept_adi		varchar(30),
     primary key (dept_id)
    )ENGINE=InnoDB DEFAULT CHARSET=latin5 COLLATE=latin5_turkish_ci;
   
   
   create table personel
	(personel_id         int(10) NOT NULL AUTO_INCREMENT,
	 adi_soyadi		     varchar(30) NOT NULL,
     eposta			     varchar(50) NOT NULL,
     telefon		     varchar(11) NOT NULL,
     adres		         varchar(150) NOT NULL,
     sehir 			     varchar(20) NOT NULL,
     ilce			     varchar(20) NOT NULL,
     maas			     int(10) NOT NULL,
     durum			     bit(1) NOT NULL,
     giris_tarihi	     date NOT NULL,
     ayrilis_tarihi	     date,
     gorev_id			 int(10) NOT NULL,
     dept_id             int(10),
	 foreign key (gorev_id) references gorev(gorev_id) on delete cascade,
     foreign key (dept_id) references departman(dept_id) on delete cascade,
     primary key (personel_id)
    )ENGINE=InnoDB DEFAULT CHARSET=latin5 COLLATE=latin5_turkish_ci;
    
    
      create table hareket_tipi
	(hareket_tipi_id         int(10) NOT NULL AUTO_INCREMENT,
	 hareket_adi		     varchar(30) NOT NULL,
     primary key (hareket_tipi_id)
    )ENGINE=InnoDB DEFAULT CHARSET=latin5 COLLATE=latin5_turkish_ci;
    
    
    create table pers_har
    ( per_har_id         int(10) NOT NULL AUTO_INCREMENT,
	  personel_id		 int(10) NOT NULL,
      tarih 			 date NOT NULL,
      borc				 int(10) NOT NULL,
      alacak			 int(10) NOT NULL,
      hareket_tipi_id    int(10) NOT NULL,
      foreign key(personel_id) references personel(personel_id),
      foreign key(hareket_tipi_id) references hareket_tipi(hareket_tipi_id),
     primary key (per_har_id)
    )ENGINE=InnoDB DEFAULT CHARSET=latin5 COLLATE=latin5_turkish_ci;

    
    