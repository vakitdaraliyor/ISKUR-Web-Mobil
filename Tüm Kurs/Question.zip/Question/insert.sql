DELETE from departman;
DELETE from gorev;
DELETE from personel;
delete from hareket_tipi;
DELETE from pers_har;

INSERT INTO departman(dept_adi) values ('Yazılım');
INSERT INTO departman(dept_adi) values ('Satış');
INSERT INTO departman(dept_adi) values ('Teknik Destek');
INSERT INTO departman(dept_adi) values ('Muhasebe');
INSERT INTO departman(dept_adi) values ('Yönetim');
INSERT INTO departman(dept_adi) values ('AR-GE');

INSERT INTO gorev(gorev_adi) values ('Genel Müdür');
INSERT INTO gorev(gorev_adi) values ('Müdür');
INSERT INTO gorev(gorev_adi) values ('Ofis Görevlisi');
INSERT INTO gorev(gorev_adi) values ('Satışçı');
INSERT INTO gorev(gorev_adi) values ('Teknik Eleman');


INSERT INTO personel(adi_soyadi, eposta, telefon, adres, sehir, ilce, maas, durum, giris_tarihi, ayrilis_tarihi, gorev_id, dept_id)
values ('Mustafa Çelikcan', 'mustafacelikcan@gmail.com', '05546789999', 'Mustafa Çelikcan Adres', 'ANKARA', 'ÇANKAYA', 3500, 1, '2003-01-15', null, 1, 5);             

INSERT INTO personel(adi_soyadi, eposta, telefon, adres, sehir, ilce, maas, durum, giris_tarihi, ayrilis_tarihi, gorev_id, dept_id)
values ('Refai Tüfekçi', 'rtufekci@gmail.com', '05426771998', 'Refai Tüfekçi  Adres', 'ANKARA', 'ETİMESGUT', 2500, 1, '2005-10-12', null, 2, 2);             

INSERT INTO personel(adi_soyadi, eposta, telefon, adres, sehir, ilce, maas, durum, giris_tarihi, ayrilis_tarihi, gorev_id, dept_id)
values ('Kerem Yılmaz', 'krmyilmaz@gmail.com', '05304533312', 'Kerem Yılmaz  Adres', 'ANKARA', 'ALTINDAĞ', 1500, 1, '2006-09-01', null, 5, 3); 

INSERT INTO personel(adi_soyadi, eposta, telefon, adres, sehir, ilce, maas, durum, giris_tarihi, ayrilis_tarihi, gorev_id, dept_id)
values ('Ruhi Eser', 'reser@gmail.com', '05527724511', 'Ruhi Eser Adres', 'ANKARA', 'ÇANKAYA', 1200, 1, '2007-10-1', null, 3, null); 

INSERT INTO personel(adi_soyadi, eposta, telefon, adres, sehir, ilce, maas, durum, giris_tarihi, ayrilis_tarihi, gorev_id, dept_id)
values ('Ekrem Güven', 'ekremguven@gmail.com', '05326982991', 'Ekrem Güven  Adres', 'ANKARA', 'YENİMAHALLE', 2000, 1, '2007-11-02', null, 4, 2); 

INSERT INTO personel(adi_soyadi, eposta, telefon, adres, sehir, ilce, maas, durum, giris_tarihi, ayrilis_tarihi, gorev_id, dept_id)
values ('Tufan Bayram', 'tbaygin06@hotmail.com', '05546789999', 'Tufan Baygın Adres', 'ANKARA', 'ÇANKAYA', 2000, 1, '2008-01-15', null, 4, 2); 

INSERT INTO hareket_tipi(hareket_adi) values ('Maaş Hakedişi');
INSERT INTO hareket_tipi(hareket_adi) values ('Maaş Ödemesi');
INSERT INTO hareket_tipi(hareket_adi) values ('Avans Çekme');


INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (1, '2014-01-31', 0, 3500, 1);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (1, '2014-01-31', 3500, 0, 2);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (1, '2014-02-28', 0, 3500, 1);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (1, '2014-02-28', 3500, 0, 2);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (1, '2014-03-31', 0, 3500, 1);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (1, '2014-03-31', 3500, 0, 2);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (1, '2014-04-30', 0, 3500, 1);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (1, '2014-04-30', 3500, 0, 2);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (1, '2014-05-31', 0, 3500, 1);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (1, '2014-05-31', 3500, 0, 2);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (1, '2014-06-30', 0, 3500, 1);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (1, '2014-06-30', 3500, 0, 2);

INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (2, '2014-01-31', 0, 2500, 1);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (2, '2014-01-31', 2500, 0, 2);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (2, '2014-02-28', 0, 2500, 1);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (2, '2014-02-28', 2500, 0, 2);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (2, '2014-03-31', 0, 2500, 1);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (2, '2014-03-31', 2500, 0, 2);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (2, '2014-04-30', 0, 2500, 1);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (2, '2014-04-30', 2500, 0, 2);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (2, '2014-05-31', 0, 2500, 1);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (2, '2014-05-31', 2500, 0, 2);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (2, '2014-06-30', 0, 2500, 1);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (2, '2014-06-30', 2500, 0, 2);

INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (3, '2014-01-31', 0, 1500, 1);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (3, '2014-01-31', 1500, 0, 2);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (3, '2014-02-28', 0, 1500, 1);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (3, '2014-02-28', 1500, 0, 2);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (3, '2014-03-31', 0, 1500, 1);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (3, '2014-03-31', 1500, 0, 2);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (3, '2014-04-30', 0, 1500, 1);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (3, '2014-04-30', 1500, 0, 2);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (3, '2014-05-31', 0, 1500, 1);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (3, '2014-05-31', 1500, 0, 2);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (3, '2014-06-30', 0, 1500, 1);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (3, '2014-06-30', 1500, 0, 2);

INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (4, '2014-01-31', 0, 1200, 1);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (4, '2014-01-31', 1200, 0, 2);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (4, '2014-02-28', 0, 1200, 1);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (4, '2014-02-28', 1200, 0, 2);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (4, '2014-03-31', 0, 1200, 1);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (4, '2014-03-31', 1200, 0, 2);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (4, '2014-04-30', 0, 1200, 1);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (4, '2014-04-30', 1200, 0, 2);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (4, '2014-05-31', 0, 1200, 1);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (4, '2014-05-31', 1200, 0, 2);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (4, '2014-06-30', 0, 1200, 1);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (4, '2014-06-30', 1200, 0, 2);

INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (5, '2014-01-31', 0, 2000, 1);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (5, '2014-01-31', 2000, 0, 2);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (5, '2014-02-28', 0, 2000, 1);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (5, '2014-02-28', 2000, 0, 2);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (5, '2014-03-31', 0, 2000, 1);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (5, '2014-03-31', 2000, 0, 2);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (5, '2014-04-30', 0, 2000, 1);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (5, '2014-04-30', 2000, 0, 2);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (5, '2014-05-31', 0, 2000, 1);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (5, '2014-05-31', 2000, 0, 2);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (5, '2014-06-30', 0, 2000, 1);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (5, '2014-06-30', 2000, 0, 2);

INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (6, '2014-01-31', 0, 2000, 1);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (6, '2014-01-31', 2000, 0, 2);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (6, '2014-02-28', 0, 2000, 1);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (6, '2014-02-28', 2000, 0, 2);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (6, '2014-03-31', 0, 2000, 1);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (6, '2014-03-31', 2000, 0, 2);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (6, '2014-04-30', 0, 2000, 1);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (6, '2014-04-30', 2000, 0, 2);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (6, '2014-05-31', 0, 2000, 1);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (6, '2014-05-31', 2000, 0, 2);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (6, '2014-06-30', 0, 2000, 1);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (6, '2014-06-30', 2000, 0, 2);

UPDATE personel set maas = maas * 0.7;

INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (1, '2014-07-31', 0, 2450, 1);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (1, '2014-07-31', 1250, 1250, 2);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (1, '2014-07-31', 625, 0, 3);

INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (1, '2014-08-31', 0, 2450, 1);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (1, '2014-08-31', 1250, 1250, 2);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (1, '2014-08-31', 625, 0, 3);

INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (1, '2014-09-30', 0, 2450, 1);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (1, '2014-09-30', 1250, 1250, 2);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (1, '2014-09-30', 625, 0, 3);

INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (1, '2014-10-31', 0, 2450, 1);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (1, '2014-10-31', 1250, 1250, 2);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (1, '2014-10-31', 625, 0, 3);

INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (1, '2014-11-30', 0, 2450, 1);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (1, '2014-11-30', 1250, 1250, 2);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (1, '2014-11-30', 625, 0, 3);

INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (1, '2014-12-31', 0, 2450, 1);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (1, '2014-12-31', 1250, 1250, 2);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (1, '2014-12-31', 625, 0, 3);

INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (2, '2014-07-31', 0, 1750, 1);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (2, '2014-07-31', 875, 875, 2);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (2, '2014-08-31', 0, 1750, 1);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (2, '2014-08-31', 875, 875, 2);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (2, '2014-09-30', 0, 1750, 1);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (2, '2014-09-30', 875, 875, 2);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (2, '2014-10-31', 0, 1750, 1);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (2, '2014-10-31', 875, 875, 2);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (2, '2014-11-30', 0, 1750, 1);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (2, '2014-11-30', 875, 875, 2);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (2, '2014-12-31', 0, 1750, 1);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (2, '2014-12-31', 875, 875, 2);

INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (2, '2014-07-31', 437, 0, 3);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (2, '2014-08-31', 437, 0, 3);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (2, '2014-09-30', 437, 0, 3);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (2, '2014-10-31', 437, 0, 3);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (2, '2014-11-30', 437, 0, 3);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (2, '2014-12-31', 437, 0, 3);

INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (3, '2014-07-31', 0, 1050, 1);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (3, '2014-07-31', 525, 525, 2);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (3, '2014-08-31', 0, 1050, 1);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (3, '2014-08-31', 525, 525, 2);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (3, '2014-09-30', 0, 1050, 1);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (3, '2014-09-30', 525, 525, 2);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (3, '2014-10-31', 0, 1050, 1);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (3, '2014-10-31', 525, 525, 2);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (3, '2014-11-30', 0, 1050, 1);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (3, '2014-11-30', 525, 525, 2);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (3, '2014-12-31', 0, 1050, 1);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (3, '2014-12-31', 525, 525, 2);

INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (3, '2014-07-31', 262, 0, 3);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (3, '2014-08-31', 262, 0, 3);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (3, '2014-09-30', 262, 0, 3);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (3, '2014-10-31', 262, 0, 3);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (3, '2014-11-30', 262, 0, 3);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (3, '2014-12-31', 262, 0, 3);

INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (4, '2014-07-31', 0, 840, 1);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (4, '2014-07-31', 420, 420, 2);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (4, '2014-08-31', 0, 840, 1);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (4, '2014-08-31', 420, 420, 2);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (4, '2014-09-30', 0, 840, 1);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (4, '2014-09-30', 420, 420, 2);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (4, '2014-10-31', 0, 840, 1);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (4, '2014-10-31', 420, 420, 2);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (4, '2014-11-30', 0, 840, 1);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (4, '2014-11-30', 420, 420, 2);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (4, '2014-12-31', 0, 840, 1);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (4, '2014-12-31', 420, 420, 2);

INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (4, '2014-07-31', 210, 0, 3);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (4, '2014-08-31', 210, 0, 3);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (4, '2014-09-30', 210, 0, 3);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (4, '2014-10-31', 210, 0, 3);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (4, '2014-11-30', 210, 0, 3);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (4, '2014-12-31', 210, 0, 3);

INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (5, '2014-07-31', 0, 1400, 1);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (5, '2014-07-31', 700, 700, 2);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (5, '2014-08-31', 0, 1400, 1);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (5, '2014-08-31', 700, 700, 2);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (5, '2014-09-30', 0, 1400, 1);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (5, '2014-09-30', 700, 700, 2);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (5, '2014-10-31', 0, 1400, 1);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (5, '2014-10-31', 700, 700, 2);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (5, '2014-11-30', 0, 1400, 1);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (5, '2014-11-30', 700, 700, 2);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (5, '2014-12-31', 0, 1400, 1);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (5, '2014-12-31', 700, 700, 2);

INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (5, '2014-07-31', 350, 0, 3);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (5, '2014-08-31', 350, 0, 3);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (5, '2014-09-30', 350, 0, 3);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (5, '2014-10-31', 350, 0, 3);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (5, '2014-11-30', 350, 0, 3);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (5, '2014-12-31', 350, 0, 3);

INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (6, '2014-07-31', 0, 1400, 1);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (6, '2014-07-31', 700, 700, 2);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (6, '2014-08-31', 0, 1400, 1);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (6, '2014-08-31', 700, 700, 2);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (6, '2014-09-30', 0, 1400, 1);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (6, '2014-09-30', 700, 700, 2);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (6, '2014-10-31', 0, 1400, 1);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (6, '2014-10-31', 700, 700, 2);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (6, '2014-11-30', 0, 1400, 1);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (6, '2014-11-30', 700, 700, 2);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (6, '2014-12-31', 0, 1400, 1);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (6, '2014-12-31', 700, 700, 2);

INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (6, '2014-07-31', 350, 0, 3);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (6, '2014-08-31', 350, 0, 3);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (6, '2014-09-30', 350, 0, 3);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (6, '2014-10-31', 350, 0, 3);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (6, '2014-11-30', 350, 0, 3);
INSERT INTO pers_har(personel_id, tarih, borc, alacak, hareket_tipi_id) values (6, '2014-12-31', 350, 0, 3);

